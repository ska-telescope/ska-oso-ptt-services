from typing import List, Optional

from pydantic import Field

from ska_oso_pdm._shared import PdmObject, Target
from ska_oso_pdm._shared.atoms import TerseStrEnum
from ska_oso_pdm.proposal.investigator import Investigator
from ska_oso_pdm.proposal.result import Result

from .data_product_sdp import DataProductSDP
from .data_product_src import DataProductSRC
from .document import Document
from .observation_set import ObservationSets


class ProposalTypeENUM(TerseStrEnum):
    STANDARD_PROPOSAL = "standard_proposal"
    KEY_SCIENCE_PROPOSAL = "key_science_proposal"
    DIRECTOR_TIME_PROPOSAL = "director_time_proposal"


class ProposalSubType(TerseStrEnum):
    TARGET_OF_OPPORTUNITY = "target_of_opportunity"
    JOINT_PROPOSAL = "joint_proposal"
    COORDINATED_PROPOSAL = "coordinated_proposal"
    LONG_TERM_PROPOSAL = "long_term_proposal"


class ScienceCategory(TerseStrEnum):
    SC_1 = "Cosmology"
    SC_2 = "Cradle of Life"
    SC_3 = "Epoch of Re-ionization"
    SC_4 = "Extra Galactic continuum"
    SC_5 = "Extra Galactic Spectral line"
    SC_6 = "Gravitational Waves"
    SC_7 = "High Energy Cosmic Particles"
    SC_8 = "HI Galaxy science"
    SC_9 = "Magnetism"
    SC_10 = "Our Galaxy"
    SC_11 = "Pulsars"
    SC_12 = "Solar, Heliospheric and Ionospheric Physics"
    SC_13 = "Transients"
    SC_14 = "VLBI"


class ProposalType(PdmObject):
    """Represents the categories of a proposal."""

    main_type: ProposalTypeENUM = Field(
        default=ProposalTypeENUM.STANDARD_PROPOSAL, description="Type of the proposal"
    )
    sub_type: List[ProposalSubType] = Field(
        default_factory=list, description="Optional sub-type of the proposal"
    )


class Info(PdmObject):
    title: str = Field(default="", description="Title of the proposal")
    proposal_type: ProposalType = Field(
        default_factory=ProposalType,
        description="Proposal type and optional sub-type combination",
    )
    abstract: str = Field(default="", description="Abstract of the proposal")
    science_category: Optional[str] = Field(
        default=None, description="Science category of the proposal"
    )
    targets: List[Target] = Field(
        default_factory=list, description="List of targets associated with the proposal"
    )
    documents: List[Document] = Field(
        default_factory=list,
        description="List of documents associated with the proposal",
    )
    investigators: List[Investigator] = Field(
        default_factory=list,
        description="Information on the investigators that have been invited onto the proposal",
    )
    observation_sets: List[ObservationSets] = Field(
        default_factory=list,
        description="List of observations associated with the proposal",
    )
    data_product_sdps: List[DataProductSDP] = Field(
        default_factory=list,
        description="List of data products associated with the SDP",
    )
    data_product_src_nets: List[DataProductSRC] = Field(
        default_factory=list,
        description="List of data products associated with the SRC-Net",
    )
    results: List[Result] = Field(
        default_factory=list,
        description="List of target/observation set combinations with SensCalc results",
    )
