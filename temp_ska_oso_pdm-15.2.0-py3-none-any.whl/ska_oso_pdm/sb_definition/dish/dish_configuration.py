"""
The ska_oso_pdm.sb_definition.dish.dish_configuration module defines
simple Python representation of how SKA MID dishes in sub-array should be configured.
"""

from enum import Enum

from ska_oso_pdm._shared import DishConfigurationID, PdmObject

__all__ = ["ReceiverBand", "DishConfiguration"]


class ReceiverBand(Enum):
    """
    ReceiverBand is an enumeration of SKA MID receiver bands.
    """

    BAND_1 = "1"
    BAND_2 = "2"
    BAND_5A = "5a"
    BAND_5B = "5b"


class DishConfiguration(PdmObject):
    """
    DishConfiguration specifies how SKA MID dishes in a sub-array should be
    configured. At the moment, this is limited to setting the receiver band.
    """

    dish_configuration_id: DishConfigurationID
    receiver_band: ReceiverBand
