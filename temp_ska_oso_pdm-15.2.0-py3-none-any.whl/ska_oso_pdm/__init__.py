"""
The ska_oso_pdm module contains Python Pydantic models representing the SKA
Project Data Model (PDM) and OpenAPI v3.1 schemas.
"""

from ._shared import Metadata, PdmObject, Target
from .entity_status_history import (
    OSOEBStatusHistory,
    ProjectStatusHistory,
    SBDStatusHistory,
    SBIStatusHistory,
)
from .execution_block import OSOExecutionBlock
from .project import Project
from .proposal import Proposal
from .sb_definition import SBDefinition
from .sb_instance import SBInstance
