from datetime import datetime, timezone
from typing import Optional

from pydantic import AwareDatetime, Field

from ska_oso_pdm._shared.pdm_object import PdmObject


class Metadata(PdmObject):
    """Represents metadata about other entities."""

    version: int = 1
    created_by: Optional[str] = None
    created_on: AwareDatetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    last_modified_by: Optional[str] = None
    last_modified_on: AwareDatetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
