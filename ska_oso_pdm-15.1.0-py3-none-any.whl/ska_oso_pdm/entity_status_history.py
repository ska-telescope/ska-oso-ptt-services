"""
a simple Python representation of the SBD, SBI and EB status history
"""

from typing import Optional

from pydantic import Field

from ska_oso_pdm._shared import (
    ExecutionBlockID,
    ProjectID,
    SBDefinitionID,
    SBInstanceID,
)
from ska_oso_pdm._shared.atoms import TerseStrEnum
from ska_oso_pdm._shared.metadata import Metadata
from ska_oso_pdm._shared.pdm_object import PdmObject


class SBDStatus(TerseStrEnum):
    DRAFT = "draft"
    SUBMITTED = "submitted"
    READY = "ready"
    INPROGRESS = "in_progress"
    OBSERVED = "observed"
    SUSPENDED = "suspended"
    FAILED_PROCESSING = "failed_processing"
    COMPLETE = "complete"


class SBIStatus(TerseStrEnum):
    CREATED = "created"
    EXECUTING = "executing"
    OBSERVED = "observed"
    FAILED = "failed"


class OSOEBStatus(TerseStrEnum):
    CREATED = "created"
    FULLY_OBSERVED = "fully_observed"
    FAILED = "failed"


class ProjectStatus(TerseStrEnum):
    DRAFT = "draft"
    SUBMITTED = "submitted"
    READY = "ready"
    INPROGRESS = "In Progress"
    OBSERVED = "observed"
    COMPLETE = "complete"
    CANCELLED = "cancelled"
    OUT_OF_TIME = "Out of Time"


class EntityStatus(PdmObject):
    metadata: Metadata = Field(default_factory=Metadata)


class SBDStatusHistory(EntityStatus):

    sbd_ref: SBDefinitionID
    current_status: SBDStatus = SBDStatus.DRAFT
    previous_status: Optional[SBDStatus] = SBDStatus.DRAFT


class SBIStatusHistory(EntityStatus):

    sbi_ref: SBInstanceID
    current_status: SBIStatus = SBIStatus.CREATED
    previous_status: Optional[SBIStatus] = SBIStatus.CREATED


class OSOEBStatusHistory(EntityStatus):

    eb_ref: ExecutionBlockID
    current_status: OSOEBStatus = OSOEBStatus.CREATED
    previous_status: Optional[OSOEBStatus] = OSOEBStatus.CREATED


class ProjectStatusHistory(EntityStatus):

    prj_ref: ProjectID
    current_status: ProjectStatus = ProjectStatus.DRAFT
    previous_status: Optional[ProjectStatus] = ProjectStatus.DRAFT
