from pydantic import Field, HttpUrl

from ska_oso_pdm._shared import PdmObject
from ska_oso_pdm._shared.atoms import TerseStrEnum
from ska_oso_pdm._shared.ids import DocumentID


class DocumentType(TerseStrEnum):
    PROPOSAL_SCIENCE = "proposal_science"
    PROPOSAL_TECHNICAL = "proposal_technical"


class Document(PdmObject):
    document_id: DocumentID = Field(
        description="Unique identifier for the Documents class"
    )
    link: HttpUrl = Field(description="URL link of the document")
    type: str = Field(description="Type/usage of document being stored")
