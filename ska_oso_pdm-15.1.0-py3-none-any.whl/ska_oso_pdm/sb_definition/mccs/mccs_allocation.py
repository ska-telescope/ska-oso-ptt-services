"""
The entities module provides simple Python representations of the structured
request and response for the TMC CentralNode.AssignResources and Configure commands.
"""

from pydantic import Field

from ska_oso_pdm._shared import MCCSConfigurationID, PdmObject, SubArrayLOW

__all__ = ["Aperture", "MCCSAllocation", "SubarrayBeamConfiguration"]

MAX_SUBARRAY_BEAM_ID = 48
MAX_STATION_ID = 511


class Aperture(PdmObject):
    """
    Aperture specifies how the aperture of a subarray beam should be
    configured.

    :param station_id: ID of station
    :param substation_id: ID of sub station
    :param weighting_key: weighting key value
    """

    station_id: int = Field(ge=0, le=MAX_STATION_ID)
    substation_id: int
    weighting_key: str = "uniform"


class SubarrayBeamConfiguration(PdmObject):
    """
    SubarrayBeamConfiguration specifies how SKA LOW sub-array should be
    configured.

    :param apertures: list of aperture in this subarray
    :param number_of_channels: number of channels in this subarray beam
    :param subarray_beam_id: ID of subarray beam this config maps to
    """

    apertures: list[Aperture]
    number_of_channels: int
    subarray_beam_id: int = Field(ge=1, le=MAX_SUBARRAY_BEAM_ID)


class MCCSAllocation(PdmObject):
    """
    MCCSAllocation is a Python representation of the MCCS allocation segment
    of a scheduling block.

    :param mccs_config_id: stations ID's to allocate
    :param configuration: name of pre-defined/standard configuration
    :param subarray_beams: subarray beam list
    """

    mccs_config_id: MCCSConfigurationID
    configuration: SubArrayLOW
    subarray_beams: list[SubarrayBeamConfiguration]
